# Casino-Modelle (Java-Texturepack)

Erzeugt von `pack/CasinoModelle.java`. Neu erzeugen mit JDK 21 im Ordner `pack`:

```
java CasinoModelle.java .
```

Danach liegen hier `assets/` (76 Modelle) und eine Vorschau in `pack/vorschau/modelle.png`.

## Wie das Plugin sie nutzt

Ein normaler Gegenstand bekommt `custom_model_data` mit den Strings `["casino", <name>]`, siehe `gui/Modelle.java`.

- **Mit Pack:** Der Client zeigt das Casino-Modell.
- **Ohne Pack:** Der Client zeigt den normalen Gegenstand, nie den lila-schwarzen Fehlwürfel.

Die Definitionen unter `assets/minecraft/items/` greifen nur bei Index 0 = `casino`. Sonst gilt exakt das Vanilla-Modell aus 1.21.8.

| Basis-Gegenstand | Modelle |
| --- | --- |
| Netherstern, Smaragd, Diamant, Glocke, Melonenscheibe, Süße Beeren | `walze_stern` … `walze_beere` (Walzen-Kacheln) |
| Papier | 52 Karten `karte_<herz/karo/pik/kreuz>_<1..13>`, Jetons, `kessel`, `rad`, `rad_zeiger`, `nummer_1..3`, `zielflagge`, `x2` |
| Karte (Map) | `karte_rueckseite` |
| Gold- und Eisennugget | Jetons `chip_10` … `chip_1000` |
| Schneeball | `kugel` (kleiner 3D-Würfel) |
| Rohgold | `muenze` |

## Ins Netzwerk-Pack (erst bei der Veröffentlichung, mit Ja des Nutzers)

Der Pack-Generator (`NetzwerkPack/PackGenerator.java`) bekommt einen kleinen Schritt, ähnlich wie `writeGokarts`. Er kopiert `AxxinCasino/pack/java/assets/**` unverändert nach `assets/` im Pack. Die Dateien unter `assets/minecraft/items/` sind neu. Bisher überschreibt das Pack keine Vanilla-Item-Definition (Stand pack-2a86294b).

Vorher prüfen:

- `git fetch` im NetzwerkPack, weil andere Chats daran arbeiten.
- Die Pflichtliste des Packs muss erhalten bleiben.
- Release und Manifest laufen wie bei jedem Pack-Release.

Bedrock: Geyser zeigt diese Java-Modelle nicht. Bedrock-Spieler sehen die Basis-Gegenstände, eigene Bedrock-Modelle macht die Bedrock-Abteilung.
